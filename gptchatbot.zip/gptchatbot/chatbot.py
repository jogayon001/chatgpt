import os
import shutil
import logging

from langchain.document_loaders import PyPDFDirectoryLoader
from langchain.indexes import VectorstoreIndexCreator
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import Chroma

from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
import gradio as gr

from consume import move_files_to_temp
from utils import TEMP_FOLDER

os.environ['OPENAI_API_KEY'] = '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'

# setup temp files
move_files_to_temp()

# Now you can use PyPDFLoader to load the PDF
loader = PyPDFDirectoryLoader(TEMP_FOLDER)

index = VectorstoreIndexCreator().from_loaders([loader])

documents = []
documents.extend(loader.load())

text_splitter = CharacterTextSplitter(chunk_size=800, chunk_overlap=0)
documents = text_splitter.split_documents(documents)

embeddings = OpenAIEmbeddings()

db = Chroma.from_documents(documents, embeddings)

retriever = db.as_retriever(search_type="similarity", search_kwargs={"k":1})

qa = RetrievalQA.from_chain_type(llm=OpenAI(), chain_type="stuff", retriever=retriever)

# Front end web app
with gr.Blocks() as demo:
    gr.Markdown(
    """
    # Hello!
    Hello! I am an assistant trained on the PDF.
    """)
    chatbot = gr.Chatbot()
    msg = gr.Textbox(placeholder="Ask anything about the PDF...")
    clear = gr.Button("Clear")

    initial_message = ""
    def user(user_message, history):
        try:
            # Get response from QA chain
            answer = qa({"query": user_message})['result']
            logging.info(f"Chatbot response: {answer}")
            # Append user message and response to chat history
            history.append((user_message, answer))
            return gr.update(value=""), history
        except Exception as e:
            # Log the error
            logging.exception(f"An error occurred during processing: {str(e)}")
            history.append((user_message, "Oops! An error occurred during processing. Please try again."))
            return gr.update(value=""), history
    msg.submit(user, [msg, chatbot], [msg, chatbot], queue=False)
    clear.click(lambda: None, None, chatbot, queue=False)

def run():
    demo.launch(server_name="127.0.0.1",debug=False)
    # server_name="0.0.0.0"
    # http://123.123.123.123:7860

if __name__ == "__main__":
    run()