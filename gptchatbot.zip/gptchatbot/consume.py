import os
import shutil

from utils import TEMP_FOLDER, MAIN_FOLDER

def move_files_to_temp():
    # create the temp folder if it doesn't exist
    if not os.path.exists(TEMP_FOLDER):
        os.makedirs(TEMP_FOLDER)

    # walk through main folder
    for dirpath, dirnames, filenames in os.walk(MAIN_FOLDER):
        for file in filenames:
            # construct full file path
            src_file = os.path.join(dirpath, file)
            # construct destination file path
            dst_file = os.path.join(TEMP_FOLDER, file)
            # move file from src to dst
            shutil.copy(src_file, dst_file)

    print("All files have been moved to the temp folder.")
