MAIN_FOLDER = r"C:\Users\63917\Documents\OpenAI\TempData"
TEMP_FOLDER = r"C:\Users\63917\Documents\OpenAI\TempData_temp"